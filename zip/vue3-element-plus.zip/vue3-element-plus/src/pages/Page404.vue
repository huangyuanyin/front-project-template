<!--

@author: pan
@createDate: 2022-12-03 07:08
-->
<script setup lang="ts"></script>

<template>
  <div>Page404</div>
</template>

<style lang="scss" scoped></style>
