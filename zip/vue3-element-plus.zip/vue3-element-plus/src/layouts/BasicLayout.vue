<!--

@author: pan
@createDate: 2022-12-03 07:04
-->
<script setup lang="ts"></script>

<template>
  <div class="basicLayout">
    <div class="leftPanel">
      <router-link :to="{ name: 'Home' }">首页</router-link>
    </div>
    <div class="rightPanel"><router-view></router-view></div>
  </div>
</template>

<style lang="scss" scoped>
.basicLayout {
  display: flex;
  height: 100%;
  width: 100%;
  flex-direction: row;
  .leftPanel {
    width: 260px;
    flex-shrink: 0;
  }
  .rightPanel {
    flex: 1;
  }
}
</style>
