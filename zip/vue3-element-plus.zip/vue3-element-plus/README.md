# 前端项目模板

不同的分支代表不同的项目模板

| 分支名            | 说明                              |
| :---------------- | :-------------------------------- |
| vue3              | vue3 项目模板                     |
| vue3-element-plus | 基于 vue3 模板，集成 element-plus |
| vue3-vant         | 基于 vue3 模板，集成 vant         |
| vitepress-doc     | 基于 viteress 的文档模板          |
| vue3-ui-lib       | 用于编写 vue3 ui 组件             |

## 当前为 `vue3-element-plus` 模板，基于 vite 的 TS 项目(包管理工具使用的 pnpm)

**已集成插件如下:**

- element-plus 2.x
- @vueuse/core 9.x
- @vueuse/motion 2.x-beta
- animate.css 4.x
- axios 1.x
- dayjs 1.x
- element-resize-detector 1.x
- js-cookie 3.x
- lodash-es 4.x
- modern-normalize 1.x
- pinia 2.x
- pinia-plugin-persist 1.x
- vue 3.x
- vue-request 1.x
- vue-router 4.x
- vxe-table 4.x
- jest 29.x
- xe-utils 3.x: xe-utils 是 vxe-table 的依赖，项目中需要使用辅助方法，请优先使用 lodash-es 提供的
  **已配置特性:**

- 集成 sass
- 集成 postcss-preset-env 插件，会自动给 css 的属性增加浏览器前缀
- 已集成 unplugin-vue-components 插件，会对 src/components 目录下的文件进行全局按需引入
- 已集成 unplugin-vue-components 插件，会对 element-plus 组件自动引入
- 已集成 vite-plugin-style-import 插件，解决 Message 这类组件无法自动引入问题
- 已集成 vite-plugin-svg-icons 插件，配合 src/components/SvgIcon.vue 文件，可以直接使用 src/assets/svg 目录下的 svg 文件
- 已集成 vite-plugin-inspect 插件，可以看到每个插件对源文件都做了哪些修改
- 已集成 vite-plugin-mock 插件，用于在本地 mock 后端的服务和数据
- eslint 进行静态代码分析
- prettier 进行代码格式化
- commitlint 对 git commit 信息进行格式验证
- standard-version 生成 CHANGELOG

## scripts 说明

- dev: 本地启动 vite 服务
- build: 本地打包
- preview: 对本地打包的结果进行预览
- format: 使用 prettier 对代码进行格式化
- eslint-fix: 使用 eslint 对代码进行静态检查，并自动修复错误
- test: 执行 jest 测试
- test-c: 生成 jest 测试报告
- git-commit: 用于代替 git commit，用于输出格式标准的 commit 信息
- release: 打版本，生成 CHANAGELOG
- release-major: 更新主版本号，并生成 CHANAGELOG
- release-minor: 更新次版本号，并生成 CHANAGELOG
- release-patch: 更新补丁版本号，并生成 CHANAGELOG

## 配置文件说明

- .commitlintrc.cjs/.versionrc.cjs/changelog.config.cjs: git commit 和 changelog 配置相关文件
- .eslintignore/.eslintrc.cjs: eslint 配置相关文件
- .prettierignore/.prettierrc: perttier 配置相关文件
- postcss.config.cjs: postcss 配置文件
- tsconfig.json/tsconfig.node.json: ts 配置文件
- vite.config.ts: vite 配置文件
- components.d.ts: unplugin-vue-components 组件自动生成/修改的文件，从该文件中可以得知，哪些组件被自动全局按需引入了
- vite-env.d.ts: vite 相关的 ts 配置文件。如需配置全局属性的 ts 声明或.env 文件的属性/类型声明，则在此文件中完成
- src/routes/index.ts: vue-router 配置文件，路由和路由守卫的入口文件
