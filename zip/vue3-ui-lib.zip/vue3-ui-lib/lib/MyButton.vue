<!--

@file: MyButton.vue
@author: pan
@createDate: 2022-12-15 22:10
-->
<script setup lang="ts">
withDefaults(
  defineProps<{
    type?: 'blue' | 'red'
  }>(),
  { type: 'blue' }
)
</script>

<template>
  <button :class="type"><slot>按钮</slot></button>
</template>

<style lang="scss" scoped>
.red {
  background-color: red;
  color: #fff;
}
.blue {
  background-color: blue;
  color: #fff;
}
</style>
