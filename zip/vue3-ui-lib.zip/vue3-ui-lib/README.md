# 前端项目模板

不同的分支代表不同的项目模板

| 分支名            | 说明                              |
| :---------------- | :-------------------------------- |
| vue3              | vue3 项目模板                     |
| vue3-element-plus | 基于 vue3 模板，集成 element-plus |
| vue3-vant         | 基于 vue3 模板，集成 vant         |
| vitepress-doc     | 基于 viteress 的文档模板          |
| vue3-ui-lib       | 用于编写 vue3 ui 组件             |

## 当前为 `vue3-ui-lib` 模板，基于 vite 的 TS 项目(包管理工具使用的 pnpm)

**目录说明**

```
| lib            该目录是自定义组件入口目录
   |- index.ts   该文件是组件的入口文件，所有的组件都要从这个文件中导出
| dist           该目录是打包文件存放的目录
| vite.config.ts 需要修改 build.lib.name, build.lib.fileName 配置，改为实际的组件名和文件名，rollupOptions.external和rollupOptions.output.globals也要根据实际需求修改
| package.json   name, version, main, module, exports要根据实际情况修改
```

**`package.json`部分配置说明**

```json
{
  /*
   1. 用于定义package.json文件和该文件所在目录根目录中.js文件和无拓展名文件的处理方式。值为'moduel'则当作es模块处理；值为'commonjs'则被当作commonJs模块处理
   2. 目前node默认的是如果pacakage.json没有定义type字段，则按照commonJs规范处理
   3. node官方建议包的开发者明确指定package.json中type字段的值
   4. 无论package.json中的type字段为何值，.mjs的文件都按照es模块来处理，.cjs的文件都按照commonJs模块来处理
    */
  "type": "module",
  /*
   如果需要避免这个包被发布到公共仓库上去，则可以设置为true，如果需要对外发布，则需要设置为false
   */
  "private": false,
  /*
  执行 npm pub 命令时哪些文件会被发布到npm仓库
   */
  "files": ["dist"],
  // 使用 require('xxx') 方式引入时, 引入的是这个文件
  "main": "./dist/my-button.umd.cjs",
  // 使用 import x from 'xxx' 方式引入组件时，引入的是这个文件
  "module": "./dist/my-button.js",
  // 组件ts类型声明文件的入口文件
  "types": "./dist/index.d.ts",
  /*
  定义外部可访问的资源。
  如果不定义，那么整个发布目录下的资源都是可以访问的。
  如果定义了，那只能访问定义的资源。
  ".": {
      "import": "./dist/my-button.js",
      "require": "./dist/my-button.umd.cjs"
    }
    上面这个配置表示当使用 import 和 require 方式引入时，分别引入的是哪个具体的js
   
   "./dist/style.css": "./dist/style.css"
   上面这个配置表示当使用 import 'xxx/dist/style.css'时访问的是 dist 目录下的 style.css文件

   定义了exports之后，如果想访问 import 'xx/dist/scss/index.scss' 会报错。 因为exports中未声明这个资源
   要么就添加这个资源的定义. 要么就删除exports定义，删除了exports定义之后，发布目录下的所有文件就都可以直接访问了
  */
  "exports": {
    ".": {
      "import": "./dist/my-button.js",
      "require": "./dist/my-button.umd.cjs"
    },
    "./dist/style.css": "./dist/style.css"
  },
  // 如果是打包成了一个可执行cli，那这里就指定这个cli的名称和cli文件的路径
  "bin": { "npm": "./cli.js" },
  // 提交bug的url和（或）邮件地址
  "bugs": {
    "url": "http://github.com/owner/project/issues",
    "email": "project@hostname.com"
  },
  // 指定执行publish命令时，会发布到哪个仓库. 该方式可以用于避免代码不小心被发布到公共仓库
  "publishConfig": {
    "registry": "http://localhost:2000"
  }
}
```

**已集成插件如下:**

- @vueuse/core 9.x
- @vueuse/motion 2.x-beta
- animate.css 4.x
- axios 1.x
- dayjs 1.x
- element-resize-detector 1.x
- js-cookie 3.x
- lodash-es 4.x
- modern-normalize 1.x
- pinia 2.x
- pinia-plugin-persist 1.x
- vue 3.x
- vue-request 1.x
- vue-router 4.x
- vxe-table 4.x
- jest 29.x
- xe-utils 3.x: xe-utils 是 vxe-table 的依赖，项目中需要使用辅助方法，请优先使用 lodash-es 提供的

**已配置特性:**

- 集成 sass
- 集成 postcss-preset-env 插件，会自动给 css 的属性增加浏览器前缀
- 已集成 unplugin-vue-components 插件，会对 src/components 目录下的文件进行全局按需引入
- 已集成 vite-plugin-svg-icons 插件，配合 src/components/SvgIcon.vue 文件，可以直接使用 src/assets/svg 目录下的 svg 文件
- 已集成 vite-plugin-inspect 插件，可以看到每个插件对源文件都做了哪些修改
- 已集成 vite-plugin-mock 插件，用于在本地 mock 后端的服务和数据
- eslint 进行静态代码分析
- prettier 进行代码格式化
- commitlint 对 git commit 信息进行格式验证
- standard-version 生成 CHANGELOG

## scripts 说明

- dev: 本地启动 vite 服务
- build: 本地打包
- format: 使用 prettier 对代码进行格式化
- eslint-fix: 使用 eslint 对代码进行静态检查，并自动修复错误
- test: 执行 jest 测试
- test-c: 生成 jest 测试报告
- git-commit: 用于代替 git commit，用于输出格式标准的 commit 信息
- release: 打版本，生成 CHANAGELOG
- release-major: 更新主版本号，并生成 CHANAGELOG
- release-minor: 更新次版本号，并生成 CHANAGELOG
- release-patch: 更新补丁版本号，并生成 CHANAGELOG

## 配置文件说明

- .commitlintrc.cjs/.versionrc.cjs/changelog.config.cjs: git commit 和 changelog 配置相关文件
- .eslintignore/.eslintrc.cjs: eslint 配置相关文件
- .prettierignore/.prettierrc: perttier 配置相关文件
- postcss.config.cjs: postcss 配置文件
- tsconfig.json/tsconfig.node.json: ts 配置文件
- vite.config.ts: vite 配置文件
- components.d.ts: unplugin-vue-components 组件自动生成/修改的文件，从该文件中可以得知，哪些组件被自动全局按需引入了
- vite-env.d.ts: vite 相关的 ts 配置文件。如需配置全局属性的 ts 声明或.env 文件的属性/类型声明，则在此文件中完成
- src/routes/index.ts: vue-router 配置文件，路由和路由守卫的入口文件
